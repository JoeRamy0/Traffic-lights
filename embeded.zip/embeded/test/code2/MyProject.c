// Traffic Light Control using PIC16F877A
//Youssef Ramy Samy
//sec2-BN46

// Global variables
unsigned short mode;
unsigned short west_state;
unsigned short west_counter;
unsigned short south_state;
unsigned short south_counter;
bit manual_request;
bit west_has_green;

//Control Functions
void display_time(void);
void set_lights(void);
void update_auto_mode(void);
void manual_toggle(void);
//===============================
//===============================
//Interrupt(Auto/Manual Define)||
//===============================
//===============================
void interrupt() {
    if (INTCON.INTF) {           // Check if INT0 interrupt occurred
        INTCON.INTF = 0;         // Clear interrupt flag

        if (mode == 0) {         // Switching from Auto to Manual
            mode = 1;
            PORTB.B2 = 1;        // Indicator LED on
            // Set initial manual state: West RED, South GREEN
            west_state = 0;
            south_state = 0;
            west_has_green = 0;
            west_counter = 0;
            south_counter = 0;
        } else {                 // Switching from Manual to Auto
            mode = 0;
            PORTB.B2 = 0;        // Indicator LED off
            // Reset to auto cycle
            west_state = 0;
            west_counter = 15;
            south_state = 0;
            south_counter = 12;
        }

        // Update lights immediately after mode change (but not display to avoid reentrancy)
        set_lights();
    }
}
//====================================
//====================================
//Display time on 7-segment displays||
//====================================
//====================================
void display_time(void) {
    unsigned short west_tens, west_units, south_tens, south_units;

    // West street display
    west_tens = west_counter / 10;
    west_units = west_counter % 10;
    PORTA = west_tens & 0x0F;                    // Tens digit
    PORTB = (PORTB & 0x0F) | (west_units << 4);  // Units digit

    // South street display
    south_tens = south_counter / 10;
    south_units = south_counter % 10;
    PORTD = (south_tens & 0x0F) | ((south_units & 0x0F) << 4);
}
//========================
//========================
//Traffic lights Control ||
//========================
//========================
void set_lights(void) {
    PORTC = 0;  // Turn off all lights first

    // Set west lights
    switch (west_state) {
        case 0: PORTC.RC0 = 1; break;  // Red
        case 1: PORTC.RC1 = 1; break;  // Yellow
        case 2: PORTC.RC2 = 1; break;  // Green
    }

    // Set south lights
    switch (south_state) {
        case 0: PORTC.RC5 = 1; break;  // Green
        case 1: PORTC.RC4 = 1; break;  // Yellow
        case 2: PORTC.RC3 = 1; break;  // Red
    }
}
//===================
//===================
//Auto mode Control||
//===================
//===================
void update_auto_mode(void) {
    display_time();
    set_lights();
    Delay_ms(1000);

    // Decrement counters
    if (west_counter > 0) west_counter--;
    if (south_counter > 0) south_counter--;
    if (west_counter == 0 && west_state == 1 && south_counter == 0 && south_state == 1) {
        west_state = 0;
        west_counter = 15;
        south_state = 0;
        south_counter = 12;
    }
    // West street state transitions
    if (west_counter == 0) {
        switch (west_state) {
            case 0:
                west_state = 1;
                west_counter = 3;
                break;   // Red to Yellow
            case 1:
                west_state = 2;
                west_counter = 20;
                break;  // Yellow to Green
            case 2:
                west_state = 1;
                west_counter = 3;
                break;   // Green to Yellow
        }
    }

    // South street state transitions
    if (south_counter == 0) {
        switch (south_state) {
            case 0:
                south_state = 1;
                south_counter = 3;
                break;   // Green to Yellow
            case 1:
                south_state = 2;
                south_counter = 23;
                break;  // Yellow to Red
            case 2:
                south_state = 1;
                south_counter = 3;
                break;   // Red to Yellow
        }
    }

    // Special coordination between lights

}
//=====================
//=====================
//Manual mode Control||
//=====================
//=====================
void manual_toggle(void) {
    unsigned short i;

    // Both streets yellow for 3 seconds
    west_state = 1;
    south_state = 1;

    for (i = 3; i > 0; i--) {
        portb.b2=0;
        west_counter = i;
        south_counter = i;
        // Direct port manipulation instead of calling display_time()
        PORTA = (i / 10) & 0x0F;
        PORTB = (PORTB & 0x0F) | ((i % 10) << 4);
        PORTD = ((i / 10) & 0x0F) | (((i % 10) & 0x0F) << 4);

        set_lights();
        Delay_ms(1000);
        portb.b2=1;
    }

    // Toggle which street has green
    if (west_has_green) {
        west_state = 0;  // West red
        south_state = 0; // South green
        west_has_green = 0;
    } else {
        west_state = 2;  // West green
        south_state = 2; // South red
        west_has_green = 1;
    }

    west_counter = 0;
    south_counter = 0;
}
//===============
//===============
//Main Function||
//===============
//===============
void main() {
    // Initialize variables
    mode = 0;
    west_state = 0;
    west_counter = 15;
    south_state = 0;
    south_counter = 12;
    manual_request = 0;
    west_has_green = 0;

    // Port configuration
    TRISA = 0;    // All outputs
    TRISB = 0x03; // RB0 and RB1 inputs, others outputs
    TRISC = 0;    // All outputs
    TRISD = 0;    // All outputs

    // Initialize ports
    PORTA = 0;
    PORTB = 0;
    PORTC = 0;
    PORTD = 0;

    // Interrupt configuration
    OPTION_REG.INTEDG = 1; // Interrupt on rising edge
    INTCON.INTE = 1;       // Enable INT0 interrupt
    INTCON.INTF = 0;       // Clear interrupt flag
    INTCON.GIE = 1;        // Enable global interrupts

    // Initial display and lights
    display_time();
    set_lights();

    // Main loop
    while (1) {
        if (mode == 0) {  // Auto mode
            update_auto_mode();
        } else {          // Manual mode
            // Update display only in main loop (not in interrupt)
            display_time();
            set_lights();

            // Check for manual toggle button
            if (PORTB.B1) {
                Delay_ms(50); // Debounce
                if (PORTB.B1) {
                    manual_request = 1;
                    while (PORTB.B1); // Wait for button release
                }
            }

            // Process manual toggle request
            if (manual_request) {
                manual_request = 0;
                manual_toggle();
                // Update display after toggle
                display_time();
                set_lights();
            }

            Delay_ms(100); // Short delay in manual mode
        }
    }
}